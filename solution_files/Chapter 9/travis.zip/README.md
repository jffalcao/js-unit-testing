# unit-test-with-travis

[![Build Status](https://travis-ci.org/zzo/unit-test-with-travis.svg?branch=master)](https://travis-ci.org/zzo/unit-test-with-travis)

cloud based ci
