# js-unit-testing-with-travis

[![Build Status](https://travis-ci.org/zzo/js-unit-testing-with-travis.svg?branch=master)](https://travis-ci.org/zzo/js-unit-testing-with-travis)

play with cloud ci
