
var __cov_bZHzxZ15M3QIrwrprFdPTw = (Function('return this'))();
if (!__cov_bZHzxZ15M3QIrwrprFdPTw.__coverage__) { __cov_bZHzxZ15M3QIrwrprFdPTw.__coverage__ = {}; }
__cov_bZHzxZ15M3QIrwrprFdPTw = __cov_bZHzxZ15M3QIrwrprFdPTw.__coverage__;
if (!(__cov_bZHzxZ15M3QIrwrprFdPTw['/Users/screen/codecoverage/UserTemplate.js'])) {
   __cov_bZHzxZ15M3QIrwrprFdPTw['/Users/screen/codecoverage/UserTemplate.js'] = {"path":"/Users/screen/codecoverage/UserTemplate.js","s":{"1":0},"b":{},"f":{},"fnMap":{},"statementMap":{"1":{"start":{"line":1,"column":0},"end":{"line":9,"column":2}}},"branchMap":{}};
}
__cov_bZHzxZ15M3QIrwrprFdPTw = __cov_bZHzxZ15M3QIrwrprFdPTw['/Users/screen/codecoverage/UserTemplate.js'];
__cov_bZHzxZ15M3QIrwrprFdPTw.s['1']++;var UserTemplate=`
<link rel="stylesheet" type="text/css" href="user-row.css">
<div id="user_ID" class="user-row">
  <span class="user-id">ID</span>
  <span class="user-name">NAME</span>
  <span class="user-email">EMAIL</span>
  <span style="color: COLOR" class="user-favorite-color">COLOR</span>
</div>
`;
