var UserTemplate = `
<link rel="stylesheet" type="text/css" href="user-row.css">
<div id="user_ID" class="user-row">
  <span class="user-id">ID</span>
  <span class="user-name">NAME</span>
  <span class="user-email">EMAIL</span>
  <span style="color: COLOR" class="user-favorite-color">COLOR</span>
</div>
`;


