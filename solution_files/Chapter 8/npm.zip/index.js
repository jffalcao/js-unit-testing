console.log(process.env);
console.log("PORT IS", process.env.npm_package_config_port);
console.log("BOO IS", process.env.npm_package_config_boo);
